<?php
declare(strict_types=1);
session_start();

const DB_FILE = __DIR__ . '/../data/razhpoint.sqlite';
const APP_SECRET = 'CHANGE_THIS_TO_A_LONG_RANDOM_SECRET_BEFORE_PRODUCTION';

if (!is_dir(dirname(DB_FILE))) mkdir(dirname(DB_FILE), 0775, true);
$db = new PDO('sqlite:' . DB_FILE);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$db->exec("PRAGMA foreign_keys = ON");

$db->exec("CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
 password TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'buyer', created_at TEXT NOT NULL
)");
$db->exec("CREATE TABLE IF NOT EXISTS listings (
 id INTEGER PRIMARY KEY AUTOINCREMENT, seller_id INTEGER NOT NULL, game TEXT NOT NULL,
 title TEXT NOT NULL, description TEXT NOT NULL, price INTEGER NOT NULL,
 rank TEXT DEFAULT '', skins TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'active',
 created_at TEXT NOT NULL, FOREIGN KEY(seller_id) REFERENCES users(id)
)");
$db->exec("CREATE TABLE IF NOT EXISTS orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT, buyer_id INTEGER NOT NULL, seller_id INTEGER NOT NULL,
 listing_id INTEGER NOT NULL, amount INTEGER NOT NULL, payment_status TEXT NOT NULL DEFAULT 'unpaid',
 order_status TEXT NOT NULL DEFAULT 'pending', created_at TEXT NOT NULL,
 FOREIGN KEY(buyer_id) REFERENCES users(id), FOREIGN KEY(seller_id) REFERENCES users(id),
 FOREIGN KEY(listing_id) REFERENCES listings(id)
)");

$adminEmail='admin@razhpoint.test';
$stmt=$db->prepare("SELECT id FROM users WHERE email=?"); $stmt->execute([$adminEmail]);
if (!$stmt->fetch()) {
  $s=$db->prepare("INSERT INTO users(name,email,password,role,created_at) VALUES(?,?,?,?,?)");
  $s->execute(['RAZHPOINT Admin',$adminEmail,password_hash('Admin123!',PASSWORD_DEFAULT),'admin',date('c')]);
}

function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function user(): ?array { return $_SESSION['user'] ?? null; }
function csrf(): string { if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(24)); return $_SESSION['csrf']; }
function check_csrf(): void { if(!hash_equals($_SESSION['csrf']??'', $_POST['csrf']??'')) die('Invalid CSRF token'); }
function redirect(string $url): never { header("Location: $url"); exit; }
function money(int $n): string { return 'Rp '.number_format($n,0,',','.'); }

$action=$_GET['action']??'home';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  check_csrf();
  if ($action==='register') {
    $name=trim($_POST['name']??''); $email=strtolower(trim($_POST['email']??'')); $pass=$_POST['password']??'';
    if(strlen($name)<2 || !filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($pass)<8) { $_SESSION['flash']='Data register tidak valid.'; redirect('?action=register'); }
    try {
      $s=$db->prepare("INSERT INTO users(name,email,password,role,created_at) VALUES(?,?,?,?,?)");
      $s->execute([$name,$email,password_hash($pass,PASSWORD_DEFAULT),'buyer',date('c')]);
      $_SESSION['user']=['id'=>(int)$db->lastInsertId(),'name'=>$name,'email'=>$email,'role'=>'buyer'];
      redirect('?action=dashboard');
    } catch(PDOException $ex) { $_SESSION['flash']='Email sudah terdaftar.'; redirect('?action=register'); }
  }
  if ($action==='login') {
    $email=strtolower(trim($_POST['email']??'')); $pass=$_POST['password']??'';
    $s=$db->prepare("SELECT * FROM users WHERE email=?"); $s->execute([$email]); $u=$s->fetch(PDO::FETCH_ASSOC);
    if($u && password_verify($pass,$u['password'])) { $_SESSION['user']=['id'=>(int)$u['id'],'name'=>$u['name'],'email'=>$u['email'],'role'=>$u['role']]; redirect('?action=dashboard'); }
    $_SESSION['flash']='Email atau password salah.'; redirect('?action=login');
  }
  if ($action==='logout') { session_destroy(); redirect('?'); }
  if ($action==='create_listing') {
    if(!user() || user()['role']==='buyer' || !in_array(user()['role'],['seller','admin'],true)) { $_SESSION['flash']='Akun belum memiliki akses seller.'; redirect('?action=dashboard'); }
    $game=trim($_POST['game']??''); $title=trim($_POST['title']??''); $desc=trim($_POST['description']??'');
    $price=(int)($_POST['price']??0); $rank=trim($_POST['rank']??''); $skins=trim($_POST['skins']??'');
    if(!$game||!$title||!$desc||$price<1000) { $_SESSION['flash']='Lengkapi data listing dan harga minimal Rp1.000.'; redirect('?action=sell'); }
    $s=$db->prepare("INSERT INTO listings(seller_id,game,title,description,price,rank,skins,status,created_at) VALUES(?,?,?,?,?,?,?,?,?)");
    $s->execute([user()['id'],$game,$title,$desc,$price,$rank,$skins,'active',date('c')]);
    $_SESSION['flash']='Listing berhasil dibuat.'; redirect('?action=dashboard');
  }
  if ($action==='order') {
    if(!user()) redirect('?action=login');
    $id=(int)($_POST['listing_id']??0);
    $s=$db->prepare("SELECT * FROM listings WHERE id=? AND status='active'"); $s->execute([$id]); $l=$s->fetch(PDO::FETCH_ASSOC);
    if(!$l || $l['seller_id']==user()['id']) { $_SESSION['flash']='Listing tidak tersedia.'; redirect('?'); }
    $s=$db->prepare("INSERT INTO orders(buyer_id,seller_id,listing_id,amount,created_at) VALUES(?,?,?,?,?)");
    $s->execute([user()['id'],$l['seller_id'],$l['id'],$l['price'],date('c')]);
    // Payment gateway is intentionally a production integration point.
    $_SESSION['flash']='Order dibuat. Hubungkan payment gateway untuk menerima pembayaran otomatis.';
    redirect('?action=orders');
  }
  if ($action==='promote_seller') {
    if(!user()) redirect('?action=login');
    $db->prepare("UPDATE users SET role='seller' WHERE id=? AND role='buyer'")->execute([user()['id']]);
    $_SESSION['user']['role']='seller'; $_SESSION['flash']='Mode seller aktif.'; redirect('?action=dashboard');
  }
  if ($action==='order_status' && user()['role']==='admin') {
    $id=(int)($_POST['id']??0); $status=$_POST['status']??'pending';
    $allowed=['pending','paid','delivered','completed','cancelled','disputed'];
    if(in_array($status,$allowed,true)) $db->prepare("UPDATE orders SET order_status=? WHERE id=?")->execute([$status,$id]);
    redirect('?action=admin');
  }
}

$flash=$_SESSION['flash']??''; unset($_SESSION['flash']);
$q=trim($_GET['q']??''); $game=trim($_GET['game']??'');
$sql="SELECT l.*,u.name seller FROM listings l JOIN users u ON u.id=l.seller_id WHERE l.status='active'";
$args=[];
if($q!==''){ $sql.=" AND (l.title LIKE ? OR l.game LIKE ? OR l.rank LIKE ?)"; $args=["%$q%","%$q%","%$q%"]; }
if($game!==''){ $sql.=" AND l.game=?"; $args[]=$game; }
$sql.=" ORDER BY l.id DESC";
$s=$db->prepare($sql); $s->execute($args); $listings=$s->fetchAll(PDO::FETCH_ASSOC);

function layout(string $title, string $content, string $flash=''): void {
  $u=user(); ?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=e($title)?> — RAZHPOINT</title><link rel="stylesheet" href="?asset=css"></head><body>
<header><div class="wrap nav"><a class="brand" href="?"><b>RAZH</b><span>POINT</span></a><nav>
<a href="?">Marketplace</a><?php if($u): ?><a href="?action=dashboard">Dashboard</a><a href="?action=orders">Order</a><?php endif; ?>
<?php if($u && $u['role']==='admin'): ?><a href="?action=admin">Admin</a><?php endif; ?>
</nav><div class="navright"><?php if($u): ?><span class="hello"><?=e($u['name'])?></span><a class="btn" href="?action=logout">Keluar</a><?php else: ?><a class="btn" href="?action=login">Masuk</a><a class="btn primary" href="?action=register">Daftar</a><?php endif; ?></div></div></header>
<?php if($flash): ?><div class="wrap"><div class="flash"><?=e($flash)?></div></div><?php endif; ?>
<main class="wrap"><?=$content?></main><footer><div>© 2026 RAZHPOINT</div><div>Marketplace Akun Game</div></footer></body></html><?php
}

if(isset($_GET['asset']) && $_GET['asset']==='css'){
header('Content-Type:text/css'); echo <<<CSS
:root{--bg:#06100b;--card:#0c1a13;--card2:#10251a;--line:#1c3828;--green:#36e47b;--muted:#91a99a;--white:#f3fff7}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 80% 0,#123b25,#06100b 40%);color:var(--white);font:15px Arial,sans-serif}a{color:inherit;text-decoration:none}.wrap{max-width:1150px;margin:auto;padding:0 20px}
header{border-bottom:1px solid var(--line);background:#06100bdd;position:sticky;top:0;z-index:3}.nav{height:74px;display:flex;align-items:center;gap:30px}.brand{font-size:24px;font-weight:900}.brand span{color:var(--green)}nav{display:flex;gap:20px;color:#b7cabe;font-size:14px}.navright{margin-left:auto;display:flex;gap:10px;align-items:center}.hello{color:var(--muted)}.btn{display:inline-block;border:1px solid var(--line);background:#0d1b15;padding:10px 14px;border-radius:9px;font-weight:700}.primary{background:var(--green);color:#041009;border-color:var(--green)}
.hero{padding:65px 0 35px;display:grid;grid-template-columns:1.2fr .8fr;gap:40px;align-items:center}.pill{color:var(--green);font-weight:800;font-size:12px}.hero h1{font-size:54px;line-height:1.02;margin:15px 0}.green{color:var(--green)}.muted{color:var(--muted);line-height:1.65}.search{display:flex;gap:8px;margin-top:25px}.input,.textarea,.select{width:100%;background:#07130c;border:1px solid var(--line);border-radius:9px;padding:12px;color:white;outline:none}.search .input{flex:1}.heroCard,.card,.panel{background:#0c1a13;border:1px solid var(--line);border-radius:16px}.heroCard{padding:25px}.bigprice{font-size:28px;color:var(--green);font-weight:900;margin:12px 0}.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:18px}.stat{background:#07130c;padding:12px;border-radius:10px}.stat small{display:block;color:var(--muted);margin-top:4px}
.sectionHead{display:flex;justify-content:space-between;align-items:center;margin:35px 0 18px}.filters{display:flex;gap:8px;overflow:auto;margin-bottom:18px}.chip{padding:8px 13px;border:1px solid var(--line);border-radius:99px;color:#b8cbbf}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:17px}.thumb{height:145px;background:linear-gradient(135deg,#163a25,#0a160f);display:flex;align-items:center;justify-content:center;color:var(--green);font-size:38px;font-weight:900}.body{padding:16px}.title{font-weight:800;font-size:16px}.meta{color:var(--muted);font-size:12px;margin:9px 0;line-height:1.5}.row{display:flex;justify-content:space-between;align-items:center;gap:10px}.price{font-weight:900;font-size:18px}.flash{margin-top:18px;padding:12px 15px;border:1px solid #28633f;background:#10281a;border-radius:10px;color:#aef3c7}.panel{padding:24px;margin:35px 0}.formgrid{display:grid;grid-template-columns:1fr 1fr;gap:14px}.full{grid-column:1/-1}.label{display:block;color:#a9bfb0;font-size:13px;margin-bottom:7px}.table{width:100%;border-collapse:collapse}.table th,.table td{padding:12px;border-bottom:1px solid var(--line);text-align:left;font-size:13px}.badge{padding:5px 8px;border-radius:99px;background:#163b27;color:#8ff1ae;font-size:11px}.detail{display:grid;grid-template-columns:1fr 1fr;gap:25px;margin:40px 0}.empty{text-align:center;padding:50px;color:var(--muted)}footer{border-top:1px solid var(--line);margin-top:60px;padding:28px 20px;color:var(--muted);display:flex;justify-content:space-between}
@media(max-width:800px){.hero,.detail{grid-template-columns:1fr}.grid{grid-template-columns:1fr 1fr}.nav nav{display:none}.hero h1{font-size:42px}.formgrid{grid-template-columns:1fr}.full{grid-column:auto}}
@media(max-width:520px){.grid{grid-template-columns:1fr}.hello{display:none}.hero h1{font-size:36px}}
CSS; exit; }

if($action==='home'){
  $cards=''; foreach($listings as $l){$cards.='<article class="card"><div class="thumb">'.e(strtoupper(substr($l['game'],0,3))).'</div><div class="body"><div class="title">'.e($l['title']).'</div><div class="meta">'.e($l['game']).' • '.e($l['rank']).' • '.e($l['skins']).'</div><div class="row"><span class="price">'.money((int)$l['price']).'</span><a class="btn" href="?action=detail&id='.(int)$l['id'].'">Detail</a></div></div></article>'; }
  $content='<section class="hero"><div><span class="pill">MARKETPLACE AKUN GAME</span><h1>Beli & jual akun game dengan <span class="green">lebih teratur.</span></h1><p class="muted">RAZHPOINT adalah starter marketplace untuk listing akun game, order, seller dashboard, dan admin management.</p><form class="search"><input class="input" name="q" placeholder="Cari akun, game, rank..." value="'.e($q).'"><button class="btn primary">Cari</button></form></div><div class="heroCard"><b>RAZHPOINT</b><h2>Marketplace siap dikembangkan</h2><p class="muted">Frontend + backend + SQLite sudah dalam satu project.</p><div class="stats"><div class="stat"><b>Login</b><small>Auth</small></div><div class="stat"><b>Listing</b><small>Seller</small></div><div class="stat"><b>Order</b><small>Buyer</small></div></div></div></section>';
  $content.='<div class="sectionHead"><h2>Akun Terbaru</h2><span class="muted">'.count($listings).' listing</span></div><div class="filters"><a class="chip" href="?">Semua</a><a class="chip" href="?game=Mobile Legends">Mobile Legends</a><a class="chip" href="?game=Free Fire">Free Fire</a><a class="chip" href="?game=PUBG Mobile">PUBG Mobile</a></div><div class="grid">'.($cards?:'<div class="empty">Belum ada listing. Daftar sebagai seller untuk menambahkan akun.</div>').'</div>';
  layout('Marketplace',$content,$flash); exit;
}
if($action==='login' || $action==='register'){
  $isLogin=$action==='login';
  $content='<div class="panel" style="max-width:520px;margin:55px auto"><h2>'.($isLogin?'Masuk':'Daftar RAZHPOINT').'</h2><p class="muted">'.($isLogin?'Masuk untuk membeli dan mengelola order.':'Buat akun untuk mulai membeli atau menjual.').'</p><form method="post" action="?action='.$action.'"><input type="hidden" name="csrf" value="'.csrf().'">'.(!$isLogin?'<label class="label">Nama</label><input class="input" name="name" required>':'').'<label class="label">Email</label><input class="input" name="email" type="email" required><label class="label">Password</label><input class="input" name="password" type="password" minlength="8" required><br><br><button class="btn primary">'.($isLogin?'Masuk':'Daftar').'</button></form></div>';
  layout($isLogin?'Masuk':'Daftar',$content,$flash); exit;
}
if($action==='detail'){
  $id=(int)($_GET['id']??0); $s=$db->prepare("SELECT l.*,u.name seller FROM listings l JOIN users u ON u.id=l.seller_id WHERE l.id=?");$s->execute([$id]);$l=$s->fetch(PDO::FETCH_ASSOC);
  if(!$l) { layout('Tidak ditemukan','<div class="empty">Listing tidak ditemukan.</div>'); exit; }
  $buy=user()?'<form method="post" action="?action=order"><input type="hidden" name="csrf" value="'.csrf().'"><input type="hidden" name="listing_id" value="'.$l['id'].'"><button class="btn primary">Buat Order • '.money((int)$l['price']).'</button></form>':'<a class="btn primary" href="?action=login">Masuk untuk membeli</a>';
  $content='<div class="detail"><div class="heroCard"><div class="thumb">GAME</div></div><div class="panel" style="margin:0"><span class="pill">'.e($l['game']).'</span><h1 style="font-size:34px">'.e($l['title']).'</h1><p class="muted">'.nl2br(e($l['description'])).'</p><p>Rank: <b>'.e($l['rank']).'</b><br>Skin/Item: <b>'.e($l['skins']).'</b><br>Seller: <b>'.e($l['seller']).'</b></p><div class="price">'.money((int)$l['price']).'</div><br>'.$buy.'</div></div>';
  layout('Detail Akun',$content,$flash); exit;
}
if($action==='dashboard'){
  if(!user()) redirect('?action=login'); $u=user();
  $s=$db->prepare("SELECT * FROM listings WHERE seller_id=? ORDER BY id DESC");$s->execute([$u['id']]);$mine=$s->fetchAll(PDO::FETCH_ASSOC);
  $rows=''; foreach($mine as $l)$rows.='<tr><td>'.e($l['title']).'</td><td>'.e($l['game']).'</td><td>'.money((int)$l['price']).'</td><td><span class="badge">'.e($l['status']).'</span></td></tr>';
  $content='<div class="panel"><h2>Halo, '.e($u['name']).' 👋</h2><p class="muted">Role: '.e($u['role']).'</p>'.($u['role']==='buyer'?'<form method="post" action="?action=promote_seller"><input type="hidden" name="csrf" value="'.csrf().'"><button class="btn primary">Aktifkan Mode Seller</button></form>':'<a class="btn primary" href="?action=sell">+ Tambah Listing</a>').'</div>';
  if($u['role']!=='buyer')$content.='<div class="panel"><h3>Listing Saya</h3><table class="table"><tr><th>Judul</th><th>Game</th><th>Harga</th><th>Status</th></tr>'.$rows.'</table></div>';
  layout('Dashboard',$content,$flash); exit;
}
if($action==='sell'){
  if(!user() || !in_array(user()['role'],['seller','admin'],true)) redirect('?action=dashboard');
  $content='<div class="panel"><h2>Jual Akun</h2><p class="muted">Jangan memasukkan password akun game ke listing. Simpan data sensitif hanya melalui proses transfer yang aman.</p><form method="post" action="?action=create_listing"><input type="hidden" name="csrf" value="'.csrf().'"><div class="formgrid"><div><label class="label">Game</label><select class="select" name="game"><option>Mobile Legends</option><option>Free Fire</option><option>PUBG Mobile</option><option>Lainnya</option></select></div><div><label class="label">Harga (Rp)</label><input class="input" name="price" type="number" min="1000" required></div><div class="full"><label class="label">Judul listing</label><input class="input" name="title" required></div><div><label class="label">Rank</label><input class="input" name="rank"></div><div><label class="label">Skin / item</label><input class="input" name="skins"></div><div class="full"><label class="label">Deskripsi</label><textarea class="textarea" name="description" rows="6" required></textarea></div></div><br><button class="btn primary">Publikasikan</button></form></div>';
  layout('Jual Akun',$content,$flash); exit;
}
if($action==='orders'){
  if(!user()) redirect('?action=login'); $u=user();
  $s=$db->prepare("SELECT o.*,l.title FROM orders o JOIN listings l ON l.id=o.listing_id WHERE o.buyer_id=? OR o.seller_id=? ORDER BY o.id DESC");$s->execute([$u['id'],$u['id']]);$orders=$s->fetchAll(PDO::FETCH_ASSOC);
  $rows='';foreach($orders as $o)$rows.='<tr><td>#'.$o['id'].'</td><td>'.e($o['title']).'</td><td>'.money((int)$o['amount']).'</td><td><span class="badge">'.e($o['order_status']).'</span></td></tr>';
  layout('Order','<div class="panel"><h2>Order</h2><table class="table"><tr><th>ID</th><th>Listing</th><th>Amount</th><th>Status</th></tr>'.$rows.'</table></div>',$flash);exit;
}
if($action==='admin'){
  if(!user() || user()['role']!=='admin') redirect('?');
  $orders=$db->query("SELECT o.*,l.title,u.name buyer FROM orders o JOIN listings l ON l.id=o.listing_id JOIN users u ON u.id=o.buyer_id ORDER BY o.id DESC")->fetchAll(PDO::FETCH_ASSOC);
  $rows='';foreach($orders as $o){$rows.='<tr><td>#'.$o['id'].'</td><td>'.e($o['buyer']).'</td><td>'.e($o['title']).'</td><td>'.money((int)$o['amount']).'</td><td><form method="post" action="?action=order_status"><input type="hidden" name="csrf" value="'.csrf().'"><input type="hidden" name="id" value="'.$o['id'].'"><select class="select" name="status" onchange="this.form.submit()">'.implode('',array_map(fn($x)=>'<option '.($x===$o['order_status']?'selected':'').'>'.$x.'</option>',['pending','paid','delivered','completed','cancelled','disputed'])).'</select></form></td></tr>';}
  layout('Admin','<div class="panel"><h2>Admin — Orders</h2><table class="table"><tr><th>ID</th><th>Buyer</th><th>Listing</th><th>Amount</th><th>Status</th></tr>'.$rows.'</table></div>',$flash);exit;
}
redirect('?');
