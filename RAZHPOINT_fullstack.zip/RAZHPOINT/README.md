# RAZHPOINT — Marketplace Akun Game

Full-stack starter marketplace berbasis PHP 8+ dan SQLite, tanpa framework.

## Fitur
- Register / login / logout
- Password hashing
- Marketplace dan pencarian
- Detail listing
- Seller dashboard
- Tambah / hapus listing
- Buyer membuat order
- Status order
- Admin dashboard sederhana
- SQLite otomatis
- CSRF token
- Session auth
- Responsive UI

## Menjalankan lokal
1. Pastikan PHP 8+ terpasang.
2. Dari folder proyek jalankan:
   `php -S localhost:8000 -t public`
3. Buka `http://localhost:8000`

Database otomatis dibuat di `data/razhpoint.sqlite`.

## Akun admin demo
Email: admin@razhpoint.test
Password: Admin123!

Ganti password admin sebelum production.

## Production
- Aktifkan HTTPS.
- Set `display_errors=Off`.
- Pindahkan folder `data` di luar web root jika hosting memungkinkan.
- Ganti `APP_SECRET` pada `public/index.php`.
- Integrasikan payment gateway resmi pada fungsi checkout/webhook.
- Jangan menyimpan password akun game seller di database RAZHPOINT.
- Tambahkan Terms of Service, Privacy Policy, refund/dispute policy.
- Pastikan transaksi akun sesuai aturan game/platform terkait.
